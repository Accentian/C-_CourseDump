#include <iostream>
#include <iomanip>
using namespace std;

int main() {
   int num1;
   int num2;
   int num3;
   int num4;

   /* Type your code here. */
   int ans1;
   int ans2;
   double ans3;
   double ans4;
   
   cin >> num1;
   cin >> num2;
   cin >> num3;
   cin >> num4;
   
   cout << fixed << setprecision(3);
   
   ans1 = num1 * num2 * num3 * num4;
   ans2 = (num1 + num2 + num3 + num4) / 4;
   
   cout << ans1 << " " << ans2 << endl;
   
   ans3 = static_cast<double>(num1) * static_cast<double>(num2) * static_cast<double>(num3) * static_cast<double>(num4);
   ans4 = static_cast<double>(num1 + num2 + num3 + num4) / 4;
   
   cout << ans3 << " " << ans4 << endl;
   
   return 0;
}
