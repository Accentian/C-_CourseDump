#include <iostream>
#include <iomanip>               //For setprecision
using namespace std;

int main() {

   /* Type your code here. */
   double carMilesPerGallon;
   double gasDollarsPerGallon;
   double gasCost;
   
   cin >> carMilesPerGallon;
   cin >> gasDollarsPerGallon;
   
   cout << fixed << setprecision(2);
   
   gasCost = (gasDollarsPerGallon / carMilesPerGallon) * 20;
   cout << gasCost <<  " ";
   
   gasCost = (gasDollarsPerGallon / carMilesPerGallon) * 75;
   cout << gasCost <<  " ";
   
   gasCost = (gasDollarsPerGallon / carMilesPerGallon) * 500;
   cout << gasCost << endl;

   return 0;
}
