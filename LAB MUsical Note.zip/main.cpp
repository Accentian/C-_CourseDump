#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main() {

   /* Type your code here. Include the math library above first. */
   double keyFrequency;
   const double r = pow(2, (1/12.0));
   double key;
   
   cin >> keyFrequency;
   
   cout << fixed << setprecision(2);
   
   key = keyFrequency * pow(r, 0);
   cout << key << " ";
   
   key = keyFrequency * pow(r, 1);
   cout << key << " ";
   
   key = keyFrequency * pow(r, 2);
   cout << key << " ";
   
   key = keyFrequency * pow(r, 3);
   cout << key << " ";
   
   key = keyFrequency * pow(r, 4);
   cout << key << endl;

   return 0;
}
