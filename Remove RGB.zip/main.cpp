#include <iostream>
using namespace std;

int main() {

   /* Type your code here. */
   int x;
   int y;
   int z;
   
   // cout << "Enter sub-color value";
   cin >> x;
   cin >> y;
   cin >> z;
   
   int min = x;
   
   if (y < min) {
      min = y;
   }
   
   else if (z < min){
      min = z;
   }
   
   x = x - min;
   y = y - min;
   z = z - min;
   
   cout << x << " " << y << " " << z << endl;

   return 0;
}
