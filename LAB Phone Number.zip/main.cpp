#include <iostream>
using namespace std;

int main() {
   long long phoneNumber;

   cin >> phoneNumber;
   
   /* Type your code here */
   int areaCode;
   int prefix;
   int lineNumber;
   
   areaCode = phoneNumber / 10000000;
   prefix = (phoneNumber / 10000) % 1000;
   lineNumber = phoneNumber % 10000;
   
   cout << "(" << areaCode << ")" << " "<< prefix << "-" << lineNumber << endl;
   
   return 0;
}
