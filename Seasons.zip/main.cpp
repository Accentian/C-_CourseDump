#include <iostream>
#include <string>
using namespace std;

int main() {
   string inputMonth;
   int inputDay;
   
   cin >> inputMonth;
   cin >> inputDay;
   
   /* Type your code here. */
   if (inputMonth == "January" && inputDay > 0 && inputDay < 32){
        cout << "Winter" << endl;
   }
   else if (inputMonth == "Febuary" && inputDay > 0 && inputDay < 30){
        cout << "Winter" << endl;
   }
   else if (inputMonth == "March" && inputDay > 0 && inputDay < 32){
      if (inputDay <= 19){
         cout << "Winter" << endl;
      }
      
      else {
         cout << "Spring" << endl; 
      }
     
   }
   
   else if (inputMonth == "April" && inputDay > 0 && inputDay < 31){
        cout << "Spring" << endl;
   }
   else if (inputMonth == "May" && inputDay > 0 && inputDay < 32){
        cout << "Spring" << endl;
   }
   else if (inputMonth == "June" && inputDay > 0 && inputDay < 31){
      if (inputDay <= 20){
         cout << "Spring" << endl;
      }
      
      else {
         cout << "Summer" << endl; 
      }
   }
   
   else if (inputMonth == "July" && inputDay > 0 && inputDay < 32){
        cout << "Summer" << endl;
   }
   else if (inputMonth == "August" && inputDay > 0 && inputDay < 32){
        cout << "Summer" << endl;
   }
   else if (inputMonth == "September" && inputDay > 0 && inputDay < 31){
      if (inputDay <= 20){
         cout << "Spring" << endl;
      }
      
      else {
         cout << "Autumn" << endl; 
      }
   }
   
   else if (inputMonth == "October" && inputDay > 0 && inputDay < 32){
      cout << "Autumn" << endl;
   }
   else if (inputMonth == "November" && inputDay > 0 && inputDay < 31){
      cout << "Autumn" << endl;
   }
   else if (inputMonth == "December" && inputDay > 0 && inputDay < 32){
      if (inputDay <= 20){
         cout << "Autumn" << endl;
      }
      
      else {
         cout << "Winter" << endl; 
      }
   }
   
   else {
      cout << "Invalid" << endl;
   }

   return 0;
}