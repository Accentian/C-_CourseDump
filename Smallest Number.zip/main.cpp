#include <iostream>
using namespace std;

int main() {
   
   /* Type your code here. */
   int firstNum;
   int secondNum;
   int thirdNum;
   
   cin >> firstNum;
   cin >> secondNum;
   cin >> thirdNum;
   
   int min = firstNum;
   
   if (secondNum < firstNum){
      min = secondNum;
   }
   
   else if (thirdNum < firstNum){
      min = thirdNum;
   }
   
   cout << min << endl;

   return 0;
}