#include <iostream>
using namespace std;

int main() {

   /* Type your code here. */
   int userNum;
   int x;
   
   cin >> userNum;
   cin >> x;
   
   userNum = userNum / x;
   cout << userNum << " ";
   
   userNum = userNum / x;
   cout << userNum << " ";
   
   userNum = userNum / x;
   cout << userNum << endl;
   return 0;
}
