#include <iostream>
#include <cmath>
using namespace std;

int main() {
   double x;
   double y;
   double z;

   /* Type your code here. Note: Include the math library above first. */
   cin >> x;
   cin >> y;
   cin >> z;
   
   double ans1 = pow(x, z);
   double ans2 = pow(x, pow(y, z));
   double ans3 = fabs(y);
   double ans4 = sqrt(pow(x * y, z));
   
   cout << ans1 << " ";
   cout << ans2 << " ";
   cout << ans3 << " ";
   cout << ans4 << endl;
   

   return 0;
}
